from transformers import BertTokenizer, BertForSequenceClassification, Trainer, TrainingArguments
from datasets import load_dataset
import torch
import time
from tqdm.auto import tqdm
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from transformers import DataCollatorWithPadding
import numpy as np
import torch.nn as nn
from transformers import pipeline
from huggingface_hub import login



from Utils import CustomTrainer


def tokenize_function(examples):
    return tokenizer(examples['sentence'], truncation=True, padding=True)


if __name__ == "__main__":
    
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print("Device is: ", device)
    
    wandb.login()
    wandb.init(project="Project_Final_Report", name="Metrics")
    
    dataset = load_dataset("glue", "sst2")
    # advglue_dataset = load_dataset("AI-Secure/adv_glue")
    # advglue_plus_plus = load_dataset("adv_glue_plus_plus")


    # eval_dataloader = DataLoader(eval_dataloader, batch_size=32, shuffle=False)

    login('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')
    tokenizer = AutoTokenizer.from_pretrained("meta-llama/Llama-3.2-1B")
    tokenizer.pad_token = tokenizer.eos_token
    tokenized_datasets = dataset.map(tokenize_function, batched=True)
    data_collator = DataCollatorWithPadding(tokenizer=tokenizer)
    
     
    model = Llama_32("meta-llama/Llama-3.2-1B", num_labels=2, dropout_prob=0.1)
    model.pretrained_model.config.pad_token_id = tokenizer.pad_token_id
    
    training_args = TrainingArguments(
                                      output_dir='./results',
                                      num_train_epochs=3,
                                      per_device_train_batch_size=32,
                                      per_device_eval_batch_size=32,
                                      logging_dir='./logs',
                                      evaluation_strategy="epoch",
                                      learning_rate=1e-5,
                                      fp16=True,
                                      weight_decay=0.01,
                                      save_strategy="epoch",
                                  )

    trainer = CustomTrainer(
        model=model,
        args=training_args,
        train_dataset = tokenized_datasets['train'],
        eval_dataset =  tokenized_datasets['validation'],
        data_collator=data_collator,
        tokenizer=tokenizer,
    )
    
    metrics = trainer._inner_training_loop(args = training_args)
    wandb.finish()
    
    save_directory = "./Saved_Model/Llama32.pt"
    model.pretrained_model.save_pretrained(save_directory)
    tokenizer.save_pretrained(save_directory)
    
    eval_acc_temp = 0
    eval_loss_temp = 0
    eval_dataloader = load_dataset("AI-Secure/adv_glue", "adv_sst2")
    eval_dataloader = dataset.map(tokenize_function, batched=True)["validation"]
    criterion = torch.nn.CrossEntropyLoss()
    
    with tqdm(eval_dataloader, unit="batch") as eval_epoch:
        eval_epoch.set_description(f"Evaluation 1")
        for batch in eval_epoch:
            inputs = {k: v.to(device) for k, v in batch.items()}
            input_ids = inputs['input_ids'].to(device)
            attention_mask = inputs['attention_mask'].to(device)
            labels = inputs['labels']
            with torch.no_grad():
    
                outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
                loss = criterion(outputs, labels)
                eval_loss_temp += loss.item()
                eval_acc_temp += (outputs.argmax(1) == labels).sum().item()
    
    eval_loss_temp /= len(eval_dataloader)
    eval_acc_temp /= len(eval_dataloader.dataset)
    

