from transformers import BertTokenizer, BertForSequenceClassification, Trainer, TrainingArguments
from datasets import load_dataset
import torch
import time
from tqdm.auto import tqdm


class CustomTrainer(Trainer):
  def _inner_training_loop(self, batch_size=None, args=None, resume_from_checkpoint=None, trial=None, ignore_keys_for_eval=None):

      number_of_epochs = args.num_train_epochs
      start = time.time()

      train_loss = []
      eval_loss = []
      train_acc = []
      eval_acc = []


      criterion = torch.nn.CrossEntropyLoss()

      self.device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
      self.optimizer = torch.optim.Adam(self.model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
      self.scheduler = torch.optim.lr_scheduler.StepLR(self.optimizer, step_size=1, gamma=0.8)

      train_dataloader = self.get_train_dataloader()
      eval_dataloader = self.get_eval_dataloader()


      for epoch in range(number_of_epochs):

        train_loss_temp = 0
        train_acc_temp = 0

        with tqdm(train_dataloader, unit="batch") as training_epoch:
            training_epoch.set_description(f"Epoch {epoch}")

            for batch in training_epoch:

                inputs = {k: v.to(self.device) for k, v in batch.items()}
                input_ids = inputs['input_ids'].to(self.device)
                attention_mask = inputs['attention_mask'].to(self.device)
                labels = inputs['labels'].to(self.device)
                self.optimizer.zero_grad()
                outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
                loss = criterion(outputs, labels)

                loss.backward()
                # torch.nn.utils.clip_grad_norm_(model.parameters(), 2) # Another way to aviod overfitting
                self.optimizer.step()

                train_acc_temp += (outputs.argmax(1) == labels).sum().item()
                train_loss_temp += loss.item()

        self.scheduler.step()
        train_loss_temp /= len(train_dataloader)
        train_acc_temp /= len(train_dataloader.dataset)
        train_loss.append(train_loss_temp)
        train_acc.append(train_acc_temp)

        eval_acc_temp = 0
        eval_loss_temp = 0

        with tqdm(eval_dataloader, unit="batch") as eval_epoch:
            eval_epoch.set_description(f"Evaluation {epoch}")
            for batch in eval_epoch:
                inputs = {k: v.to(self.device) for k, v in batch.items()}
                input_ids = inputs['input_ids'].to(self.device)
                attention_mask = inputs['attention_mask'].to(self.device)
                labels = inputs['labels']
                with torch.no_grad():

                    outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
                    loss = criterion(outputs, labels)
                    eval_loss_temp += loss.item()
                    eval_acc_temp += (outputs.argmax(1) == labels).sum().item()

        eval_loss_temp /= len(eval_dataloader)
        eval_acc_temp /= len(eval_dataloader.dataset)
        eval_acc.append(eval_acc_temp)
        eval_loss.append(eval_loss_temp)

        # Log metrics to wandb after each epoch
        wandb.log({
            'epoch': epoch,
            'train_loss': train_loss_temp,
            'train_acc': train_acc_temp * 100,
            'eval_loss': eval_loss_temp,
            'eval_acc': eval_acc_temp * 100
        })

        print(f' Train Acc: {train_acc_temp*100:.2f} ,,, Train Loss: {train_loss_temp:.2f}')
        print(f' Eval Acc: {eval_acc_temp*100:.2f} ,,, Eval Loss: {eval_loss_temp:.2f}')


      print(f'Training completed in {time.time() - start:.2f} seconds.')
      return {"train_l":train_loss, "train_acc":train_acc, "eval_l":eval_loss, "eval_acc":eval_acc}
      
      
      
class Llama_32(nn.Module):
    def __init__(self, model_name, num_labels, dropout_prob=0.3):
        super(Llama_32, self).__init__()
        self.pretrained_model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=num_labels)
        self.dropout = nn.Dropout(dropout_prob)

    def forward(self, input_ids, attention_mask=None, labels=None):

        outputs = self.pretrained_model(input_ids=input_ids,
                                        attention_mask=attention_mask,
                                        labels=labels)

        logits = outputs.logits
        logits = self.dropout(logits)
        return logits
        
        
    